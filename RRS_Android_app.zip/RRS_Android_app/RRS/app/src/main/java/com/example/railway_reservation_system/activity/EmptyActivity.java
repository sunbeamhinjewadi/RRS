package com.example.railway_reservation_system.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.railway_reservation_system.R;

public class EmptyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);
    }
}